package gradeManage;

public class GradeBean {
	private String name;
	private int midterm;
	private int lab1;
	private int lab2;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMidterm() {
		return midterm;
	}
	public void setMidterm(int midterm) {
		this.midterm = midterm;
	}
	public int getLab1() {
		return lab1;
	}
	public void setLab1(int lab1) {
		this.lab1 = lab1;
	}
	public int getLab2() {
		return lab2;
	}
	public void setLab2(int lab2) {
		this.lab2 = lab2;
	}
	
}
